# Verana Press Kit

Official Verana brand assets and implementation notes. For usage guidelines and the latest context, visit https://verana.io/page/identity.

## Contents
- `logos/Verana-Logo-Primary.svg` — primary wordmark with logomark.
- `logos/Verana-Logo-Icon.svg` — standalone "V" logomark.
- `colors.txt` — core brand palette with HEX references.
- `typography.txt` — typography stack and usage guidance.
- `css-tokens.css` — CSS Custom Properties for implementing the palette.

## Usage reminders
- Maintain clear space equal to the height of the "V" mark.
- Minimum size: 24px (digital) / 8mm (print).
- Do not recolor, skew, add effects, or modify the artwork.
- Use Inter for UI, headings, and body text; IBM Plex Mono for code and numeric data.

For media or partnership inquiries, contact press@verana.io or visit our LinkedIn page: https://www.linkedin.com/company/verana-foundation/
